﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace connectivity
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        public static SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\pratik\asp.net\connectivity\connectivity\App_Data\con_data.mdf;Integrated Security=True;User Instance=True");
       
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Unnamed2_Click(object sender, EventArgs e)
        {
            string sql = "insert into con_tab  values('"+textbox1.Text+"','"+TextBox2.Text+"')";

            SqlDataAdapter da = new  SqlDataAdapter(sql,cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            textbox1.Text = TextBox2.Text = string.Empty;
            
        }

        private void display()
        {
            string sql = "select * from con_tab";

            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            GridView1.DataSource = dt;
            GridView1.DataBind();

            textbox1.Text = TextBox2.Text = string.Empty;
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            display();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            display();
        }
    }
}